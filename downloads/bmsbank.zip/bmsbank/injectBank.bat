@if "%~1"=="" goto skip
@setlocal enableextensions
@pushd %~dp0
.\quickbms.exe -o -w -r bank.bms "%~1" "%~dp1in\%~n1\\"
@popd
@pause
:skip