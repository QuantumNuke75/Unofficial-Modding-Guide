@if "%~1"=="" goto skip
@setlocal enableextensions
@pushd %~dp0
md "%~dp1\out\%~n1\"
md "%~dp1\in\%~n1\"
.\quickbms.exe -o bank.bms "%~1" "%~dp1out\%~n1\\"
@popd
Rem @pause
:skip